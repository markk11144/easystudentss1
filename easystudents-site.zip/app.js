const iconPaths={telegram:'<path d="m21 3-4 18-6-6-4 3 1-6L21 3Z"/><path d="m8 12 13-9-10 12"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9S4 17 4 12V6l8-3Z"/><path d="m8 12 3 3 5-6"/>',layers:'<path d="m12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',chat:'<path d="M21 11a8 8 0 0 1-8 8H7l-5 3 2-6a8 8 0 1 1 17-5Z"/><path d="M8 10h8M8 14h5"/>',book:'<path d="M12 6C9 4 5 4 3 5v15c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1v15"/>',file:'<path d="M14 2H5v20h14V7l-5-5Z"/><path d="M14 2v6h5M8 12h8M8 16h6"/>',bulb:'<path d="M9 18v-3a6 6 0 1 1 6 0v3M9 18h6M10 22h4"/>',search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',pen:'<path d="m16 3 5 5L8 21H3v-5L16 3ZM13 6l5 5"/>',format:'<path d="M5 4h14M12 4v16M8 20h8M4 8V4M20 8V4"/>',presentation:'<path d="M3 4h18v12H3zM12 16v5M7 21l5-5 5 5M7 12l3-3 3 2 4-4"/>',refresh:'<path d="M20 7A9 9 0 1 0 21 15M20 2v6h-6"/>',check:'<path d="m5 12 4 4L19 6"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>'};
function renderIcons(root=document){root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[el.dataset.icon]||iconPaths.file}</svg>`;});}
renderIcons();
const menu=document.querySelector('.menu-toggle'),mobileNav=document.querySelector('#mobile-nav');
function closeMenu(){menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Открыть меню');mobileNav.hidden=true;}
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')==='true';menu.setAttribute('aria-expanded',String(!open));menu.setAttribute('aria-label',open?'Открыть меню':'Закрыть меню');mobileNav.hidden=open;});
mobileNav.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});
document.querySelector('#year').textContent=String(new Date().getFullYear());
const dialog=document.querySelector('#content-dialog'),dialogContent=document.querySelector('#dialog-content');
let lastTrigger=null;
function openDialog(html,trigger){lastTrigger=trigger;dialogContent.innerHTML=html;dialog.showModal();document.body.style.overflow='hidden';}
dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',e=>{if(e.target===dialog){const b=dialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)dialog.close();}});
dialog.addEventListener('close',()=>{document.body.style.overflow='';lastTrigger?.focus();});
const demoNote='<p class="demo-note">Демонстрационный образец, созданный для сайта. Это не работа клиента. Оформление адаптируется под вашу методичку.</p>';
const examples={
  title:'<h2 id="dialog-title">Титульный лист</h2><p>Название работы, тема и данные располагаются в соответствии с требованиями учебного заведения.</p><div class="document-full center"><p>Наименование учебного заведения<br>Наименование кафедры</p><p class="academic-type">ИНДИВИДУАЛЬНЫЙ ПРОЕКТ</p><p class="academic-topic">«Цифровая среда и привычки студентов»</p><p>Автор: [имя скрыто]<br>Руководитель: [имя скрыто]</p><p>Город · 2026</p></div>'+demoNote,
  contents:'<h2 id="dialog-title">Содержание</h2><p>Разделы отражают ход исследования: от постановки вопроса к результатам.</p><div class="document-full"><h3>СОДЕРЖАНИЕ</h3><div class="toc-line"><span>Введение</span><b>3</b></div><div class="toc-line"><span>1. Теоретические основы</span><b>5</b></div><div class="toc-line"><span>1.1. Основные понятия</span><b>5</b></div><div class="toc-line"><span>1.2. Обзор подходов</span><b>8</b></div><div class="toc-line"><span>2. Практическое исследование</span><b>12</b></div><div class="toc-line"><span>2.1. Методика исследования</span><b>12</b></div><div class="toc-line"><span>2.2. Анализ результатов</span><b>15</b></div><div class="toc-line"><span>Заключение</span><b>19</b></div><div class="toc-line"><span>Список источников</span><b>21</b></div></div>'+demoNote,
  format:'<h2 id="dialog-title">Фрагмент оформления</h2><p>Согласованная иерархия заголовков, абзацев и подписей облегчает чтение.</p><div class="document-full"><h3>1. ОСНОВЫ ИССЛЕДОВАНИЯ</h3><p>Исследование начинается с постановки цели и определения задач. Структура помогает последовательно раскрыть тему, а каждый раздел отвечает на конкретный вопрос.</p><h3>1.1. Цель и задачи</h3><p>Цель задаёт направление исследования. Задачи описывают действия, которые помогают её достичь: изучить материалы, выбрать метод, собрать данные и сформулировать выводы.</p><p>Таблица 1 — Пример структуры исследования</p><ul><li>Теоретическая часть — понятия и подходы.</li><li>Практическая часть — методика и данные.</li><li>Заключение — результаты и ограничения.</li></ul></div>'+demoNote,
  slides:'<h2 id="dialog-title">Пример презентации</h2><p>Одна ключевая мысль на слайд, ясные подписи и спокойный темп выступления.</p><div class="full-slide"><small>ПРЕЗЕНТАЦИЯ ПРОЕКТА · 01 / 08</small><h3>От вопроса<br>к результату.</h3><p>Цифровая среда и привычки студентов</p><div class="slide-tags"><span>Цель</span><span>Метод</span><span>Вывод</span></div></div>'+demoNote
};
document.querySelectorAll('[data-example]').forEach(button=>button.addEventListener('click',()=>openDialog(examples[button.dataset.example],button)));
const legal={
 privacy:'<h2 id="dialog-title">Политика конфиденциальности</h2><p>Этот сайт знакомит с услугами easystudents и позволяет перейти в Telegram к аккаунту <a class="text-link" href="https://t.me/easystudentss" target="_blank" rel="noopener noreferrer">@easystudentss</a>. На странице нет формы заявки, платёжных полей, рекламных счётчиков и собственных аналитических cookie.</p><h3>Переписка и материалы</h3><p>Данные, которые вы добровольно отправляете исполнителю в Telegram, используются для обсуждения запроса, оценки задачи и согласованных услуг. Для первоначальной оценки можно скрыть персональные данные в документах.</p><h3>Публикация и вопросы</h3><p>Имена, переписка, отзывы и учебные материалы не публикуются без разрешения. Вопросы об использовании или удалении переданных исполнителю материалов можно направить в @easystudentss.</p><h3>Внешние платформы</h3><p>Хостинг сайта и Telegram могут обрабатывать технические данные по собственным правилам. При переходе в Telegram действуют правила этой платформы.</p><p class="demo-note">Информационная редакция. Данные исполнителя, сроки хранения и применимые условия необходимо уточнить перед публичным запуском.</p>',
 consent:'<h2 id="dialog-title">Согласие на обработку данных</h2><p>Просмотр этой страницы и нажатие кнопки Telegram сами по себе не оформляют согласие на обработку персональных данных исполнителем.</p><p>До передачи данных для оказания услуг исполнитель должен сообщить свои реквизиты, цель обработки, перечень необходимых данных, сроки и способ отзыва согласия. При необходимости отдельное согласие согласуется в переписке.</p><p>Для первого сообщения достаточно типа работы, темы и желаемого срока. Не отправляйте сведения, которые не нужны для оценки задачи.</p><p>Связь по вопросам данных: <a class="text-link" href="https://t.me/easystudentss" target="_blank" rel="noopener noreferrer">@easystudentss в Telegram</a>.</p><p class="demo-note">Информационная редакция. Полная форма согласия заполняется после указания данных исполнителя и условий обработки.</p>',
 terms:'<h2 id="dialog-title">Условия оказания консультационных услуг</h2><h3>Как согласуется задача</h3><p>До начала работы в переписке уточняются тема, требования, объём, этапы, состав материалов, итоговая стоимость, порядок оплаты и срок.</p><h3>Цены и сроки</h3><p>Суммы на сайте являются стартовыми: консультация — от 500 ₽, помощь с проектом — от 1 000 ₽, помощь с курсовой — от 1 500 ₽. Окончательная цена зависит от согласованного объёма. Указанные сроки ориентировочные.</p><h3>Обратная связь и правки</h3><p>Промежуточные результаты и замечания обсуждаются по этапам. Объём правок, изменение требований, порядок отмены и возврата средств согласуются до оплаты.</p><h3>Материалы и результат</h3><p>Формат помощи определяется вашей задачей. Полученные материалы нужно изучить и использовать с учётом правил учебного заведения. Оценку и допуск к защите определяет учебное заведение.</p><p>Связь с исполнителем: <a class="text-link" href="https://t.me/easystudentss" target="_blank" rel="noopener noreferrer">@easystudentss</a>.</p><p class="demo-note">Информационная редакция, не публичная оферта. Реквизиты исполнителя и окончательные условия указываются при согласовании заказа.</p>'
};
document.querySelectorAll('[data-legal]').forEach(link=>link.addEventListener('click',e=>{e.preventDefault();openDialog(legal[link.dataset.legal],link);}));
const hashKey=location.hash.slice(1);if(legal[hashKey])openDialog(legal[hashKey],document.querySelector(`[data-legal="${hashKey}"]`));
// Motion starts automatically, respecting the device's reduced-motion preference.
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
const finePointer=matchMedia('(hover: hover) and (pointer: fine)');
let motionEnabled=!reducedMotion.matches;
const activeEntrances=new Set();
function syncMotion(){
  motionEnabled=!reducedMotion.matches;
  document.documentElement.dataset.motion=motionEnabled?'on':'off';
  if(!motionEnabled){activeEntrances.forEach(animation=>animation.cancel());activeEntrances.clear();}
}
syncMotion();
reducedMotion.addEventListener('change',syncMotion);
function enter(element,delay=0){
  if(!motionEnabled||!element.animate)return;
  const animation=element.animate([{opacity:0,translate:'0 25px'},{opacity:1,translate:'0 0'}],{duration:700,delay,easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'});
  activeEntrances.add(animation);animation.onfinish=animation.oncancel=()=>activeEntrances.delete(animation);
}
if('IntersectionObserver' in window){
  const entrances=new IntersectionObserver(entries=>entries.forEach(entry=>{
    if(entry.isIntersecting){const siblings=Array.from(entry.target.parentElement.children);const stagger=entry.target.matches('.service-card,.benefit,.price-card,.example-card,.steps li')?Math.min(siblings.indexOf(entry.target)%3*75,150):0;enter(entry.target,stagger);entrances.unobserve(entry.target);}
  }),{threshold:.08});
  document.querySelectorAll('.hero-copy>* , .hero-art,.benefit,.section-heading,.service-card,.price-card,.example-card,.steps li,.faq-intro,.faq-list,.contact-section,.community-copy,.channel-card').forEach(element=>entrances.observe(element));
  const ambientObserver=new IntersectionObserver(entries=>entries.forEach(entry=>entry.target.classList.toggle('is-offscreen',!entry.isIntersecting)),{rootMargin:'80px'});
  document.querySelectorAll('.hero-art,.community-section').forEach(element=>ambientObserver.observe(element));
}
const header=document.querySelector('.header');
const progress=document.querySelector('.reading-progress span');
const navLinks=Array.from(document.querySelectorAll('.desktop-nav a'));
const navSections=navLinks.map(link=>document.querySelector(link.getAttribute('href')));
let scrollQueued=false;
function refreshScroll(){
  scrollQueued=false;
  const scrollRange=document.documentElement.scrollHeight-innerHeight;
  progress.style.transform=`scaleX(${scrollRange>0?Math.max(0,Math.min(1,scrollY/scrollRange)):0})`;
  header.classList.toggle('is-scrolled',scrollY>30);
  let current=-1;navSections.forEach((section,index)=>{if(section.getBoundingClientRect().top<=180)current=index;});
  navLinks.forEach((link,index)=>{if(index===current)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
}
function scheduleScroll(){if(!scrollQueued){scrollQueued=true;requestAnimationFrame(refreshScroll);}}
addEventListener('scroll',scheduleScroll,{passive:true});addEventListener('resize',scheduleScroll,{passive:true});refreshScroll();
document.querySelectorAll('.service-card,.price-card').forEach(card=>{
  let frame=0;
  card.addEventListener('pointermove',event=>{
    if(!motionEnabled||!finePointer.matches)return;
    cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const bounds=card.getBoundingClientRect();card.style.setProperty('--pointer-x',`${event.clientX-bounds.left}px`);card.style.setProperty('--pointer-y',`${event.clientY-bounds.top}px`);});
  },{passive:true});
  card.addEventListener('pointerleave',()=>cancelAnimationFrame(frame));
});
